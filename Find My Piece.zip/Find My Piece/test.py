import json
import urllib.request as urllib2
import time
import pandas as pd

def fen_examples( max_users = 3, max_games_per_user=10, sleep_time = 15 ):
    """ Grab some real game positions from the middle of actual games, and the result """
    users = users_in_team( team='coders' )
    records  = list()
    for user in users[ :max_users ]:
        ids = user_game_ids( user_name=user )
        print("Found " + str( len( ids ) ) + " for user " + user)
        try:
            maybe_empty = [ fen_ratings_and_result( id ) for id in ids[-max_games_per_user:] ]
            non_empty   = [ res for res in maybe_empty if res is not None ]
            print("Got " + str( len( non_empty ) ) + " suitable games ")
            if len( non_empty ):
                records = records + non_empty
        except:
            print("Could not get the FENS though")

        time.sleep( sleep_time )
        table = pd.DataFrame.from_records( records, columns=['fen','white_rating','black_rating','result'] )
        table.to_pickle('fens.  pkl')
        table.to_csv('fens.csv')

    return records

def users_in_team( team='coders'):
    url       = 'http://en.lichess.org/api/user?team='+team+'&nb=1000'
    data      = json.load( urllib2.urlopen( url ) )
    selection = [ d['username'] for d in data['list'] if 'classical' in d['perfs'] and int( d['perfs']['classical']['games']) > 50 ]
    return selection

def user_game_ids( user_name='Anonymous', nb=1000, min_turns=40, perf='classical'):
    """ Return list of game identifiers for a user. By default regular chess games of at least 60 moves """
    url = 'http://en.lichess.org/api/user/'+user_name+'/games?nb='+str(nb)
    try:
        data = json.load( urllib2.urlopen( url ) )
        ids = [ res['id'] for res in data['currentPageResults'] if res['perf']==perf and res['turns'] > min_turns ]
        return ids
    except:
        return []

def fen_ratings_and_result( game_id='APScK6XY', turns=30 ):
    """ Grab the fenn after a given number of moves in, also the ratings and result """
    url  = r'http://en.lichess.org/api/game/'+game_id+r'?with_fens=1'
    data = json.load( urllib2.urlopen( url ) )
    try:
        return data['fens'][ turns ],  data['players']['white']['rating'], data['players']['black']['rating'], data['winner']
    except:
        pass